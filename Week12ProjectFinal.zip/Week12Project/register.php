<?php
//create a connection with the database

$dbHost = 'localhost';
$dbUsername = 'root';
$dbpassword = '';
$dbName = 'groupproject';

//create the database connection

$conn = new mysqli($dbHost, $dbUsername, $dbpassword, $dbName );

//verification:
//verify  that the connection is built

if ($conn ->connect_error) { die("Connection failed". $conn ->connect_error);
}
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $username = $_POST ['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO students(username, password) VALUES ('$username','$password')";

    //check the sql is executed

    if ($conn->query($sql)==TRUE) {
        echo " Registration successful";
    }
}
